import sys
import copy
from collections import defaultdict

classA = defaultdict(dict)
winLose = list()
countA =0.0
countB =0.0
def buildClassifier(listy):
    global countA
    global countB

    for i in listy:
        if i.get("winLose") == "+1":
            countA += 1
            for keyy ,attNumn in i.items():
                #print (keyy," yoo ",attNumn)
                if keyy != "winLose":
                    classA[keyy][attNumn] +=1

        elif i.get("winLose") == "-1":
            countB += 1
            for key ,attNum in i.items():
                #print (key," yoop ",attNum)
                if key != "winLose":
                    classB[key][attNum] +=1

    for key,dictAttin in classA.items():
        for att in dictAttin:
            classA[key][att] = (classA[key][att] + 1)/ (countA + 2)

    for key,dictAttin in classB.items():
        for att in dictAttin:
            classB[key][att] = (classB[key][att] + 1)/ (countB + 2)


def test(testy):
    trueP = 0
    falseP = 0
    trueN = 0
    falseN = 0
    probLaplace = 1 / 2.0

    for i in testy:
        probA = 1.0
        probB = 1.0
        for keyy ,attNumn in i.items():
            if keyy != "winLose":

                if attNumn not in classA[keyy]:
                    probA = probA * probLaplace
                    probB = probB * probLaplace
                else:
                    #print (classA[keyy][attNumn], " key ", keyy," ",attNumn,i)
                    probA = probA * classA[keyy][attNumn]
                    probB = probB * classB[keyy][attNumn]


        pA =countA/ (countA + countB)
        pB =countB/ (countA + countB)

        if probA * pA > probB * pB and i.get("winLose") == "+1":
            #print("positive true",i)
            trueP += 1

        if probA * pA > probB * pB and i.get("winLose") == "-1":
            falseN += 1
            #print("negative false",i)

        if probA * pA < probB * pB and i.get("winLose") == "+1":
            falseP += 1
            #print("positive false",i)

        if probA * pA < probB * pB and i.get("winLose") == "-1":
            trueN += 1
            #print ("negative true",i)

    print( trueP," ",falseN," ",falseP ," ",trueN);


f = open(sys.argv[1],"r")
for line in f:
    table = dict()
    contents = line.split()
    table["winLose"] = contents[0]
    for i in contents[1:]:
        index , attribute = i.split(":")
        table[int(index)]=int(attribute)
        classA[int(index)][int(attribute)] = 0
    winLose.append(table)


classB = copy.deepcopy(classA)
buildClassifier(winLose)

test(winLose)

winLoset = list()
d = open(sys.argv[2],"r")
for line in d:
    table = dict()
    contents = line.split()
    table["winLose"] = contents[0]
    for i in contents[1:]:
        index , attribute = i.split(":")
        table[int(index)]=int(attribute)

    winLoset.append(table)

test(winLoset)
    #index=''.join(contents[1:])
